from fastapi import FastAPI, HTTPException

from app.schemas.meeting import (
    MeetingRequest,
    MeetingResponse
)

from app.agents.meeting_agent import MeetingAgent


app = FastAPI(
    title="AI Agent Suite",
    description="Reusable backend for AI-powered agents",
    version="1.0.0"
)


@app.get("/")
def root():
    return {
        "message": "AI Agent Suite Backend is running"
    }


@app.get("/health")
def health_check():
    return {
        "status": "healthy"
    }


# Create agent instance
meeting_agent = MeetingAgent()


@app.post(
    "/api/meeting/analyze",
    response_model=MeetingResponse
)
def analyze_meeting(request: MeetingRequest):

    try:
        result = meeting_agent.analyze(
            transcript=request.transcript
        )

        return result

    except ValueError as error:
        raise HTTPException(
            status_code=500,
            detail=str(error)
        )

    except Exception:
        raise HTTPException(
            status_code=500,
            detail="An unexpected error occurred while analyzing the meeting."
        )